<script setup lang="ts">
import { RadioGroupIndicator, RadioGroupItem } from 'radix-vue'
import { Circle } from 'lucide-vue-next'
import { cn } from '@/lib/utils'
import { type HTMLAttributes } from 'vue'

const props = defineProps<{ class?: HTMLAttributes['class'], value?: any, disabled?: boolean }>()
</script>
<template>
  <RadioGroupItem
    :value="props.value"
    :disabled="props.disabled"
    :class="cn('aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50', props.class)"
  >
    <RadioGroupIndicator class="flex items-center justify-center">
      <Circle class="h-2.5 w-2.5 fill-primary" />
    </RadioGroupIndicator>
  </RadioGroupItem>
</template>
